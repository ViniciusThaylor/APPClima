package com.example.clima;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText cityInput;
    private Button getWeatherButton;
    private TextView weatherInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityInput = findViewById(R.id.cityInput);
        getWeatherButton = findViewById(R.id.getWeatherButton);
        weatherInfo = findViewById(R.id.weatherInfo);

        getWeatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city = cityInput.getText().toString().trim();

                if (!city.isEmpty()) {
                    showWeatherForecast(city);
                } else {
                    Toast.makeText(MainActivity.this, "Digite o nome da cidade!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showWeatherForecast(String city) {
        String temperature = "25°C";
        String condition = "Ensolarado";
        String humidity = "50%";
        String wind = "15 km/h";

        String forecast = "Cidade: " + city + "\n"
                + "Temperatura: " + temperature + "\n"
                + "Condição: " + condition + "\n"
                + "Umidade: " + humidity + "\n"
                + "Vento: " + wind;

        weatherInfo.setText(forecast);
    }
}
